window.APP_URL = 'https://e-translate.herokuapp.com/api';
